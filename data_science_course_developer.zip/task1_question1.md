# Task 1, question 1

Hi,
Thank you for your question. Indeed, it is probably a write permissions issue. I suggest you try the following steps:
1.	Open your file explorer and locate your "C:/Program Files/R/R-3.5.1/library" folder
2.	Right click on it and open the “Properties” panel.
3.	Open the security tab. There you can see the different users and groups in the upper part “Group or user names” and the allowed permissions “Permissions for SYSTEM” in the lower part.
4.	Choose your user/group name and check whether the “Write” permission is allowed or denied. Click on the “Edit” button.
5.	 Try checking the box to allow the Write permission or, if the Denied box is checked for the Write permission, try unchecking it.

If you encounter any issue while doing these steps, then do not hesitate to write me back. I’ll be happy to help you. It is also possible that the company didn’t give you the correct rights on that PC and, in that case, you should contact your IT division to let them know.
Good luck!

Comment: if the student is on Linux or Mac then I would send them the commands they would have to execute. I'm using the three OSs Mac, Linux and Windows at home so I should be able to answer for all three situations.

Time necessary: 5 minutes to find the answer + 10 min to write it.
